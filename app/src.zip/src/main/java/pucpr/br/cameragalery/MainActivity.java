package pucpr.br.cameragalery;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import pucpr.br.cameragalery.database.GaleryDatabase;
import pucpr.br.cameragalery.model.Foto;
import pucpr.br.cameragalery.repository.GaleryRepository;

public class MainActivity extends AppCompatActivity {

    static final int CAMERA_PERMISSION_CODE = 2001;
    static final int CAMERA_INTENT_CODE = 3001;
    GaleryRepository galeryRepository;
    ImageView imageViewCamera;
    String picturePath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageViewCamera = findViewById(R.id.imageViewCamera);
        galeryRepository = GaleryRepository.getInstance();
        galeryRepository.setContext(MainActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String paths = "";
        for(Foto foto:galeryRepository.getFotos()){
            paths += foto.getId() + " - " +foto.getPath()+"\n";
        }
        if(paths == ""){
            paths = "EMPTYYY";
        }
        Toast.makeText(
                MainActivity.this,
                paths,
                Toast.LENGTH_LONG
        ).show();
    }

    public void buttonCameraClick(View view){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            requestCameraPermissions();
        }else{
            sendCameraIntent();
        }

    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void requestCameraPermissions(){
        if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)){
            if(checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{
                        Manifest.permission.CAMERA
                },CAMERA_PERMISSION_CODE);
            }else{
                sendCameraIntent();
            }
        }else{
            Toast.makeText(
                    MainActivity.this,
                    "Não foi possível encontrar uma câmera",
                    Toast.LENGTH_LONG
            ).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == CAMERA_PERMISSION_CODE){
            if(grantResults[0] != PackageManager.PERMISSION_GRANTED){
                Toast.makeText(MainActivity.this,"Permissão de acesso a câmera negado.",Toast.LENGTH_LONG).show();
            }else{
                sendCameraIntent();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_INTENT_CODE){
            if(resultCode == RESULT_OK){
                File file = new File(picturePath);
                if(file.exists()){
                    imageViewCamera.setImageURI(Uri.fromFile(file));
                    Foto foto = new Foto();
                    foto.setPath(picturePath);
                    if(galeryRepository.addFoto(foto)){
                        Toast.makeText(
                                MainActivity.this,
                                "Foto adicionada na galeria",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
            }else{
                Toast.makeText(
                        MainActivity.this,
                        "Não foi possível retornar a foto do aplicativo da Câmera",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    public void sendCameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_FINISH_ON_COMPLETION,true);
        if(intent.resolveActivity(getPackageManager()) != null){
            String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
            String picName = "pic_"+timeStamp;
            File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File pictureFile = null;
            try {
                pictureFile = File.createTempFile(picName,".jpg",dir);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this,"Não foi possível criar o arquivo Temporário",Toast.LENGTH_LONG).show();
            }

            if(pictureFile != null){
                picturePath = pictureFile.getAbsolutePath();
                Uri photoUri = FileProvider.getUriForFile(
                        MainActivity.this,
                        "pucpr.br.cameragalery.fileprovider",
                        pictureFile
                );
                intent.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
                startActivityForResult(intent,CAMERA_INTENT_CODE);
            }else{
                Toast.makeText(MainActivity.this,"Não foi possível abrir a Câmera",Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(MainActivity.this,"Algo deu Errado",Toast.LENGTH_LONG).show();
        }
    }
}